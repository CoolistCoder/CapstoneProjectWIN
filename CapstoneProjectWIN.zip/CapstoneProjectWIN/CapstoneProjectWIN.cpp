/*
Capstone Engine created by Alec Roberts and Steven Cole (team Alpha Sapphire)
*/

#include <iostream>
using namespace std;

int main()
{
    std::cout << "Hellaaaa World!\n";
    return 0;
}
